import os
os.system('cmd /k ')