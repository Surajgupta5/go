import yaml

# import aa as dat

with open(r'stored_file.yaml') as file:
    doc = yaml.load(file, Loader=yaml.FullLoader)

 

    sort_file = yaml.dump(doc)
    print(sort_file)


with open(r'a/aa.py', 'w') as file:
    documents = yaml.dump(sort_file[1:-5], file)
  


 # fetched_data = print(dat)

# with open(r'stored1_file.yaml') as file:
#     # The FullLoader parameter handles the conversion from YAML
#     # scalar values to Python the dictionary format
#     stored_list = yaml.load(file, Loader=yaml.FullLoader)

 

    # print(stored_list)